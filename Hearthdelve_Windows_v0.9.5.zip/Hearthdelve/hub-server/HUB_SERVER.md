# Hearthdelve hub-server (internet-listen over åbne spil)

Hubben i spillet (Multiplayer-vinduet) finder **selv** spil på samme netværk (LAN). For at se spil
**over internettet** skal én maskine køre hub-serveren, og alle spillere skriver dens adresse i feltet
*Hub-server (internet)* og trykker *Gem*.

Hub-serveren sender kun **listen** over spil. Selve spillet går stadig direkte mellem spillerne, så
**værten skal åbne port 24565 (UDP)** i sin router (eller I bruger Tailscale/ZeroTier).

## Sådan kører du den

Den kræver kun Python 3 (findes på Linux og macOS; på Windows: python.org).

```
python3 hub_server.py                # lytter på UDP-port 24567
python3 hub_server.py --port 24567
python3 hub_server.py --selftest     # tjek at den virker
```

Maskinen skal:
- være tændt, når I vil spille (fx en gammel pc, en Raspberry Pi eller en billig VPS),
- have **UDP-port 24567** åben udefra (åbn/videresend den i routeren eller i VPS'ens firewall:
  `sudo ufw allow 24567/udp`).

Spillerne skriver maskinens offentlige IP (eller domænenavn) i *Hub-server*, fx `85.12.34.56`
eller `minhub.dk` (en anden port skrives `minhub.dk:30000`).

## Altid tændt på Linux (systemd)

```
# /etc/systemd/system/hearthdelve-hub.service
[Unit]
Description=Hearthdelve hub
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 /opt/hearthdelve/hub_server.py --port 24567
Restart=always
User=nobody

[Install]
WantedBy=multi-user.target
```
`sudo systemctl enable --now hearthdelve-hub`

## Sikkerhed
- Serveren gemmer intet på disken og glemmer et spil 30 sekunder efter, at værten holder op med at melde sig.
- Højst 4 spil pr. IP-adresse og 500 i alt; lange navne klippes; ugyldige pakker ignoreres.
- Adgangskoder sendes aldrig til hub-serveren — den ved kun, *at* et spil har en kode.
