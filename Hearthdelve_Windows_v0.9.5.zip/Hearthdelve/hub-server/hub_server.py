#!/usr/bin/env python3
"""Hearthdelve multiplayer hub (v0.9.5).

A tiny lobby server: games that are hosted somewhere announce themselves here, and
players ask for the list. It does NOT carry any game traffic — players still connect
directly to the host (the host must open its game port, 24565 UDP, in the router).

Run it on a machine that is always on and has UDP port 24567 open:

    python3 hub_server.py                 # listen on 0.0.0.0:24567
    python3 hub_server.py --port 24567
    python3 hub_server.py --selftest      # check the logic, then exit

Only the Python 3 standard library is used.

Messages (UDP, one JSON object per packet, UTF-8):
  from a host:   {"t":"reg", "id", "v", "name", "host", "n", "max", "pw", "port", "busy"}
                 {"t":"unreg", "id"}
  from a player: {"t":"list", "v"}  ->  {"t":"games", "list":[{..., "ip"}]}
"""
import argparse
import json
import socket
import sys
import time

TTL = 30.0               # a game disappears 30 s after its last announcement
MAX_PER_IP = 4           # one address cannot fill the list
MAX_GAMES = 500
MAX_LIST = 100           # games sent back per answer
MAX_PACKET = 2048        # announcements are small; ignore anything bigger
TEXT_LIMIT = 32


def _txt(v, limit=TEXT_LIMIT):
    return str(v)[:limit].replace("\n", " ").replace("\r", " ")


def _int(v, lo, hi, default):
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return default


class Registry:
    """The list of announced games (kept apart from the socket so it can be tested)."""

    def __init__(self):
        self.games = {}  # (ip, id) -> entry

    def register(self, ip, msg, now):
        gid = _txt(msg.get("id", ""), 24)
        if not gid:
            return False
        key = (ip, gid)
        if key not in self.games:
            if sum(1 for k in self.games if k[0] == ip) >= MAX_PER_IP:
                return False
            if len(self.games) >= MAX_GAMES:
                return False
        self.games[key] = {
            "id": gid,
            "ip": ip,
            "v": _txt(msg.get("v", "")),
            "name": _txt(msg.get("name", "Hearthdelve")) or "Hearthdelve",
            "host": _txt(msg.get("host", "?"), 16),
            "n": _int(msg.get("n"), 0, 16, 1),
            "max": _int(msg.get("max"), 1, 16, 4),
            "pw": bool(msg.get("pw", False)),
            "port": _int(msg.get("port"), 1, 65535, 24565),
            "busy": bool(msg.get("busy", False)),
            "seen": now,
        }
        return True

    def unregister(self, ip, msg):
        self.games.pop((ip, _txt(msg.get("id", ""), 24)), None)

    def expire(self, now):
        for k in [k for k, g in self.games.items() if now - g["seen"] > TTL]:
            del self.games[k]

    def listing(self, now):
        self.expire(now)
        out = []
        for g in sorted(self.games.values(), key=lambda g: -g["seen"])[:MAX_LIST]:
            e = dict(g)
            del e["seen"]
            out.append(e)
        return out


def handle(reg, data, ip, now):
    """One packet in -> the answer to send back (or None)."""
    if len(data) > MAX_PACKET:
        return None
    try:
        msg = json.loads(data.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None
    if not isinstance(msg, dict):
        return None
    t = msg.get("t")
    if t == "reg":
        reg.register(ip, msg, now)
        return None
    if t == "unreg":
        reg.unregister(ip, msg)
        return None
    if t == "list":
        return json.dumps({"t": "games", "list": reg.listing(now)}).encode("utf-8")
    return None


def serve(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", port))
    reg = Registry()
    print("Hearthdelve hub lytter på UDP-port %d" % port, flush=True)
    while True:
        data, addr = sock.recvfrom(4096)
        reply = handle(reg, data, addr[0], time.time())
        if reply is not None:
            try:
                sock.sendto(reply, addr)
            except OSError:
                pass


def selftest():
    reg = Registry()
    now = 1000.0
    ok = True

    def check(cond, msg):
        nonlocal ok
        print(("ok   " if cond else "FAIL ") + msg)
        ok = ok and cond

    handle(reg, json.dumps({"t": "reg", "id": "a1", "v": "x", "name": "Bys", "host": "Bo", "n": 2, "pw": True}).encode(), "1.2.3.4", now)
    lst = json.loads(handle(reg, b'{"t":"list"}', "5.6.7.8", now))["list"]
    check(len(lst) == 1 and lst[0]["ip"] == "1.2.3.4" and lst[0]["pw"] is True and lst[0]["n"] == 2, "a registered game is listed with its address")
    check(handle(reg, b"not json", "9.9.9.9", now) is None and handle(reg, b"x" * 5000, "9.9.9.9", now) is None, "bad packets are ignored")
    for i in range(10):
        handle(reg, json.dumps({"t": "reg", "id": "s%d" % i}).encode(), "6.6.6.6", now)
    check(sum(1 for g in reg.games.values() if g["ip"] == "6.6.6.6") == MAX_PER_IP, "one address cannot fill the list")
    handle(reg, json.dumps({"t": "reg", "id": "a1", "name": "N" * 300}).encode(), "1.2.3.4", now)
    check(len(reg.games[("1.2.3.4", "a1")]["name"]) == TEXT_LIMIT, "long names are cut")
    handle(reg, b'{"t":"unreg","id":"a1"}', "1.2.3.4", now)
    check(("1.2.3.4", "a1") not in reg.games, "unregister removes the game")
    handle(reg, b'{"t":"reg","id":"old"}', "7.7.7.7", now)
    check(not any(g["id"] == "old" for g in reg.listing(now + TTL + 1)), "old games expire")
    return ok


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Hearthdelve multiplayer hub")
    ap.add_argument("--port", type=int, default=24567)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    serve(a.port)
